#!/bin/bash
export LD_LIBRARY_PATH=`pwd`/lib
export R_HOME=`pwd`
export R_LIBS=`pwd`/site-library
# Use cases
#./R
# Run a script with parameters
#./R --no-restore --file=examples/redshift.R --args PID tehuixtla.png
#./R --version
#./R --no-restore --file=`pwd`/examples/age.R --args 1987
echo -----------------
ls -alh
chmod +x R
ls -alh
echo =================
echo $*
fileName=$1
shift 1
echo =================
echo $fileName
echo $*
./R --no-restore --file=$fileName --args $*
echo -----------------
