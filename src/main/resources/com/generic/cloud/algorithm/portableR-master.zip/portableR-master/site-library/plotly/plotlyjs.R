download.file(
  "http://cdn.plot.ly/plotly-latest.min.js",
  "inst/htmlwidgets/lib/plotlyjs/plotly-latest.min.js"
)

download.file(
  "https://raw.githubusercontent.com/plotly/plotly.js/master/LICENSE",
  "inst/htmlwidgets/lib/plotlyjs/LICENSE"
)
